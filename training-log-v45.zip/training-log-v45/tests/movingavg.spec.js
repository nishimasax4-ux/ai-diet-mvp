// 開発者向け: 体重グラフの7日移動平均(v44)の回帰テストです。
// アプリの利用には不要なファイルです(無視して構いません)。
//   npx playwright test tests/movingavg.spec.js
const { test, expect } = require('@playwright/test');
const path = require('path');

const APP = 'file://' + path.resolve(__dirname, '../index.html');

async function finishOnboarding(page) {
  for (let i = 0; i < 8; i++) {
    const fin = page.locator('[data-ob-action="finish"]');
    if (await fin.count()) { await fin.click(); break; }
    const next = page.locator('[data-ob-action="next"]');
    if (await next.count()) { await next.click(); await page.waitForTimeout(30); } else break;
  }
}

// 40日ぶんの「ぶれながら少しずつ減る」体重を仕込む。
async function seedWeights(page, days = 40) {
  await page.evaluate((n) => {
    const we = [];
    const start = new Date('2026-07-20T00:00:00');
    let w = 78;
    for (let i = 0; i < n; i++) {
      const d = new Date(start.getTime() + i * 86400000);
      const noise = [0.9, -0.6, 0.4, -1.0, 0.2, 0.7, -0.5][i % 7];
      we.push({ date: d.toISOString().slice(0, 10), weight: Math.round((w + noise) * 10) / 10 });
      w -= 0.09;
    }
    const st = JSON.parse(localStorage.getItem('training-log-data') || '{}');
    st.weightEntries = we;
    st.goals = Object.assign({ weight: 70 }, st.goals);
    localStorage.setItem('training-log-data', JSON.stringify(st));
  }, days);
  await page.reload();
  await page.waitForTimeout(300);
  await finishOnboarding(page);
}

test.describe('体重グラフの7日移動平均', () => {
  test('移動平均は「直近7件」ではなく日付の範囲で計算される', async ({ page }) => {
    await page.goto(APP);
    await finishOnboarding(page);
    const out = await page.evaluate(() => {
      // 3日ぶんのあと、20日あけて1件。最後の点は範囲外の値に引っぱられてはいけない。
      const pts = [
        { date: '2026-01-01', value: 80 },
        { date: '2026-01-02', value: 82 },
        { date: '2026-01-03', value: 78 },
        { date: '2026-01-25', value: 70 },
      ];
      const a = movingAverage_(pts, 7);
      // 窓のちょうど境界: 1/01 と 1/08 は7日ぶん(その日+前6日)に収まらない。
      const edge = movingAverage_([
        { date: '2026-01-01', value: 100 },
        { date: '2026-01-07', value: 10 },
        { date: '2026-01-08', value: 10 },
      ], 7);
      return { first: a[0].value, third: a[2].value, last: a[3].value, edge1: edge[1].value, edge2: edge[2].value };
    });
    expect(out.first).toBe(80);          // 1件目はその値そのもの
    expect(out.third).toBeCloseTo(80, 5); // (80+82+78)/3
    expect(out.last).toBe(70);            // 7日より前の点は含めない
    expect(out.edge1).toBeCloseTo(55, 5); // 1/01と1/07は同じ7日間 → (100+10)/2
    expect(out.edge2).toBe(10);           // 1/08から見ると1/01は窓の外
  });

  test('移動平均は日々のぶれをならして単調に近づく', async ({ page }) => {
    await page.goto(APP);
    await finishOnboarding(page);
    const out = await page.evaluate(() => {
      const pts = [];
      const start = new Date('2026-07-20T00:00:00').getTime();
      let w = 78;
      for (let i = 0; i < 40; i++) {
        const noise = [0.9, -0.6, 0.4, -1.0, 0.2, 0.7, -0.5, 1.1, -0.9, 0.3][i % 10];
        pts.push({ date: new Date(start + i * 86400000).toISOString().slice(0, 10), value: Math.round((w + noise) * 10) / 10 });
        w -= 0.09;
      }
      const a = movingAverage_(pts, 7);
      const ups = (arr) => arr.slice(1).filter((p, i) => p.value > arr[i].value).length;
      // 前日からの増え幅の最大値 = 「減っているのに増えて見える」度合い。
      const maxUp = (arr) => Math.max(0, ...arr.slice(1).map((p, i) => p.value - arr[i].value));
      return { rawUps: ups(pts), rawMaxUp: maxUp(pts), avgMaxUp: maxUp(a.slice(7)) };
    });
    // 生の値は1日で1.4kg以上増えて見える日があるが、移動平均ではほぼ消える。
    expect(out.rawUps).toBeGreaterThan(10);
    expect(out.rawMaxUp).toBeGreaterThan(1.4);
    expect(out.avgMaxUp).toBeLessThan(0.3);
  });

  test('体重タブに7日平均の線・凡例・1週間の変化が出る', async ({ page }) => {
    await page.goto(APP);
    await finishOnboarding(page);
    await seedWeights(page);
    await page.locator('[data-tab="weight"]').click();
    await page.waitForTimeout(300);

    const card = page.locator('.card').filter({ hasText: '体重の推移' });
    await expect(card).toContainText('7日平均');
    await expect(card).toContainText('/ 1週間');
    await expect(card).toContainText('太い線');

    const svg = card.locator('svg').first();
    const html = await svg.innerHTML();
    // 平均線(太い polyline)と、間引かれたグレーの実測の点の両方があること。
    // 実測の点は主役の色ではなく中間グレー(--ink-faint)で描く(v44.5)。
    expect(html).toContain('stroke-width="2.5"');
    expect(html).toContain('fill="var(--ink-faint)" opacity="0.6"');
    // 減量中なので1週間の変化はマイナス表示。
    await expect(card).toContainText('−');
  });

  test('記録が2件だけのときは従来どおりの折れ線のまま', async ({ page }) => {
    await page.goto(APP);
    await finishOnboarding(page);
    await page.evaluate(() => {
      const st = JSON.parse(localStorage.getItem('training-log-data') || '{}');
      st.weightEntries = [{ date: '2026-08-01', weight: 78 }, { date: '2026-08-02', weight: 77.5 }];
      localStorage.setItem('training-log-data', JSON.stringify(st));
    });
    await page.reload();
    await page.waitForTimeout(300);
    await finishOnboarding(page);
    await page.locator('[data-tab="weight"]').click();
    await page.waitForTimeout(300);
    const card = page.locator('.card').filter({ hasText: '体重の推移' });
    await expect(card).not.toContainText('7日平均');
    expect(await card.locator('svg').first().innerHTML()).toContain('r="4"');
  });
});
