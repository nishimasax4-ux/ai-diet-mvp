// 開発者向け: ボタン・チップを押したときの「押した感」の回帰テストです(v44.6)。
// アプリの利用には不要なファイルです(無視して構いません)。
//   npx playwright test tests/pressfeedback.spec.js
//
// 背景:「選択ボタンを押した時のクリック感が欲しい」というご要望。ホーム画面に
// 追加して使うPWAのため、OS標準のボタンのような押下フィードバックが無く、
// タップしてから再描画が終わるまで何の反応も見えなかった。押している間だけ
// 少し縮んで暗くなるCSSを追加し、iOSのSafari特有の「どこかにtouchstartの
// リスナーが無いと:activeが発火しない」癖に対応するダミーリスナーも登録した。
const { test, expect } = require('@playwright/test');
const path = require('path');

const APP = 'file://' + path.resolve(__dirname, '../index.html');

async function finishOnboarding(page) {
  for (let i = 0; i < 8; i++) {
    const fin = page.locator('[data-ob-action="finish"]');
    if (await fin.count()) { await fin.click(); break; }
    const next = page.locator('[data-ob-action="next"]');
    if (await next.count()) { await next.click(); await page.waitForTimeout(30); } else break;
  }
}

test.describe('ボタン・チップの押下フィードバック', () => {
  test('iOS Safariの:active発火バグ対策で、document に touchstart のリスナーを登録している', async ({ page }) => {
    await page.addInitScript(() => {
      window.__touchstartRegistered = false;
      const orig = EventTarget.prototype.addEventListener;
      EventTarget.prototype.addEventListener = function (type, ...rest) {
        if (type === 'touchstart' && this === document) window.__touchstartRegistered = true;
        return orig.call(this, type, ...rest);
      };
    });
    await page.goto(APP);
    await finishOnboarding(page);
    const registered = await page.evaluate(() => window.__touchstartRegistered);
    expect(registered).toBe(true);
  });

  test('タブバーのボタンを押している間、縮んで見た目が変わる(:active)', async ({ page }) => {
    await page.goto(APP);
    await finishOnboarding(page);
    const btn = page.locator('[data-tab="weight"]');
    const box = await btn.boundingBox();
    const restTransform = await btn.evaluate(el => getComputedStyle(el).transform);

    await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
    await page.mouse.down();
    // transition(0.1s)が完了するまで少し待ってから読む(押した直後は遷移の途中の値になるため)。
    await page.waitForTimeout(150);
    const pressedTransform = await btn.evaluate(el => getComputedStyle(el).transform);
    const pressedOpacity = await btn.evaluate(el => getComputedStyle(el).opacity);
    await page.mouse.up();

    expect(pressedTransform).not.toBe(restTransform);
    expect(Number(pressedOpacity)).toBeLessThan(1);
  });

  test('選択チップ(部位ボタンなど)にも押下時の見た目の変化がある', async ({ page }) => {
    await page.goto(APP);
    await finishOnboarding(page);
    await page.locator('[data-tab="training"]').click();
    await page.waitForTimeout(150);
    const chip = page.locator('#part-buttons .chip').first();
    const box = await chip.boundingBox();
    const restFilter = await chip.evaluate(el => getComputedStyle(el).filter);

    await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
    await page.mouse.down();
    await page.waitForTimeout(150);
    const pressedFilter = await chip.evaluate(el => getComputedStyle(el).filter);
    await page.mouse.up();

    expect(pressedFilter).not.toBe(restFilter);
  });

  test('離すと元の見た目に戻る', async ({ page }) => {
    await page.goto(APP);
    await finishOnboarding(page);
    const btn = page.locator('[data-tab="weight"]');
    const box = await btn.boundingBox();
    const restTransform = await btn.evaluate(el => getComputedStyle(el).transform);

    await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
    await page.mouse.down();
    await page.mouse.up();
    await page.waitForTimeout(150);
    const afterTransform = await btn.evaluate(el => getComputedStyle(el).transform);
    expect(afterTransform).toBe(restTransform);
  });
});
