// 開発者向け: 体重・体脂肪率グラフの「7日平均の線」と「実測の点」の色を
// 分けた回帰テストです(v44.5)。以前はどちらも同じ色(濃さだけ違う)だったのを、
// 「太い線=そのグラフの色」「点=中間グレー(--ink-faint)固定」に分けた。
// アプリの利用には不要なファイルです(無視して構いません)。
//   npx playwright test tests/chartcolors.spec.js
const { test, expect } = require('@playwright/test');
const path = require('path');

const APP = 'file://' + path.resolve(__dirname, '../index.html');

async function finishOnboarding(page) {
  for (let i = 0; i < 8; i++) {
    const fin = page.locator('[data-ob-action="finish"]');
    if (await fin.count()) { await fin.click(); break; }
    const next = page.locator('[data-ob-action="next"]');
    if (await next.count()) { await next.click(); await page.waitForTimeout(30); } else break;
  }
}

test.describe('体重・体脂肪率グラフの色分け', () => {
  test('lineChartSvgは、平均線を渡した色で、実測の点を固定のグレーで描く', async ({ page }) => {
    await page.goto(APP);
    await finishOnboarding(page);
    const svg = await page.evaluate(() => {
      const pts = [];
      for (let i = 0; i < 10; i++) pts.push({ date: `2026-01-${String(i+1).padStart(2,'0')}`, value: 80 - i * 0.2 });
      const avg = movingAverage_(pts, 7);
      return lineChartSvg(pts, '#3E63C4', null, avg);
    });
    // 平均線(太いpolyline)は渡した色そのまま
    expect(svg).toMatch(/<polyline[^>]*stroke="#3E63C4"/);
    // 実測の点は渡した色(#3E63C4)ではなく、中間グレー(--ink-faint)固定
    expect(svg).toContain('fill="var(--ink-faint)"');
    expect(svg).not.toContain('fill="#3E63C4" opacity');
  });

  test('体重グラフ(--slate)と体脂肪率グラフ(--coral)で、平均線の色が違う', async ({ page }) => {
    await page.goto(APP);
    await finishOnboarding(page);
    await page.evaluate(() => {
      profile = { age: 48, gender: '男性', height: 168, activity: '週1-2回', lifestyle: 'デスクワーク中心', timeAvail: '10-15分' };
      goals = { weight: 70, weeklyFreq: 3, paceKgPerWeek: 0.25 };
      weightEntries.length = 0;
      for (let i = 9; i >= 0; i--) {
        const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
        weightEntries.push({ date: d, weight: 78 - i * 0.1, bodyFat: 30 - i * 0.1 });
      }
      saveState();
    });
    await page.reload();
    await page.waitForTimeout(250);
    await page.locator('[data-tab="weight"]').click();
    await page.waitForTimeout(200);

    const svgs = await page.locator('#tab-content svg').all();
    expect(svgs.length).toBe(2);
    const htmls = await Promise.all(svgs.map(s => s.innerHTML()));
    // 1つ目(体重)は--slate、2つ目(体脂肪率)は--coralの太い線を持つ
    expect(htmls[0]).toContain('stroke="var(--slate)"');
    expect(htmls[1]).toContain('stroke="var(--coral)"');
    // どちらの実測点も同じグレーで統一されている
    expect(htmls[0]).toContain('fill="var(--ink-faint)"');
    expect(htmls[1]).toContain('fill="var(--ink-faint)"');
  });

  test('凡例にも、平均線の実際の色と実測点のグレーが小さく示される', async ({ page }) => {
    await page.goto(APP);
    await finishOnboarding(page);
    const legend = await page.evaluate(() => trendLegendHtml('var(--slate)'));
    expect(legend).toContain('background:var(--slate)');
    expect(legend).toContain('background:var(--ink-faint)');
    expect(legend).toContain('7日平均');
    expect(legend).toContain('実測');
  });
});
