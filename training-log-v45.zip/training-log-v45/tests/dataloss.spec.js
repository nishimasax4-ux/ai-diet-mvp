// 開発者向け: v44.9で塞いだ「記録が静かに消える」経路の回帰テストです。
// GitHub Pagesへの公開やアプリの利用には不要なファイルです(無視して構いません)。
//   npx playwright test tests/dataloss.spec.js
//
// 背景:
// このアプリは「端末のlocalStorageが正」で、その内容をまるごとシートへ書き写す
// (各シートをclearしてから入れ直す)方式のため、端末側が0件になった瞬間に同期すると
// シート = 唯一のバックアップまで空になってしまう。0件になる経路は3つあり、
// いずれも本人にとっては「バックアップが最も必要な瞬間」だった:
//   ① 機種変更した新しい端末で、接続設定を保存した直後(v44.8まで即座に同期していた)
//   ② localStorageの中身が壊れて読めなかったとき(黙って新規状態で起動していた)
//   ③ 「すべてのデータを削除」したあと(シートも消えることが書かれていなかった)
// これらをsyncToSheet内の1か所の安全弁でまとめて止める、というのが今回の修正。
const { test, expect } = require('@playwright/test');
const path = require('path');
const APP = () => 'file://' + path.resolve(__dirname, '../index.html');
const GAS = 'https://script.google.com/macros/s/fake/exec';
// index.html側の同期デバウンス(2.5秒)。ここを変えたらテストの待ち時間も追随させる。
const SYNC_DEBOUNCE_MS = 2500;

// シートの中身を持つ簡易モック。saveが来たら payload をそのまま「シート」に反映し、
// loadでは今の「シート」を返す。何が送られたかを saved 配列で観察できる。
function mockSheet(page, initialRows) {
  const state = {
    saved: [],           // save要求のたびに payload を記録
    sheet: initialRows || {},
    lastWriteAt: initialRows ? '2026-09-01T00:00:00.000Z' : null,
  };
  page.route('https://script.google.com/macros/**', (route, request) => {
    const body = JSON.parse(request.postData() || '{}');
    let out;
    if (body.action === 'save') {
      state.saved.push(body.payload);
      Object.keys(body.payload || {}).forEach(k => { state.sheet[k] = body.payload[k]; });
      state.lastWriteAt = new Date().toISOString();
      out = { status: 'ok', written: 1, lastWriteAt: state.lastWriteAt };
    } else if (body.action === 'load') {
      out = { status: 'ok', payload: state.sheet, lastWriteAt: state.lastWriteAt };
    } else if (body.action === 'ping') {
      out = { status: 'ok', backendVersion: 'v999', ai: { gemini: true, groq: true } };
    } else {
      out = { status: 'ok' };
    }
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(out) });
  });
  return state;
}

// シートに記録が入っている状態(=バックアップがある状態)
const SHEET_WITH_DATA = () => ({
  '筋トレ': { header: ['日付','部位','種目','重量kg','回数','消費カロリーkcal'], rows: [['2026-08-01','胸','ベンチプレス',50,10,10]] },
  '有酸素': { header: ['日付','種目','時間分','消費カロリーkcal'], rows: [['2026-08-02','ランニング',30,300]] },
  '体重':   { header: ['日付','体重kg','体脂肪率%'], rows: [['2026-08-01',80,''],['2026-08-02',79.5,'']] },
  '食事':   { header: ['日付','区分','メニュー','kcal','たんぱく質g','脂質g','炭水化物g'], rows: [['2026-08-01','朝食','納豆',100,8,5,6]] },
});

async function boot(page) {
  await page.goto(APP());
  for (let i = 0; i < 8; i++) {
    const f = page.locator('[data-ob-action="finish"]');
    if (await f.count()) { await f.click(); break; }
    const n = page.locator('[data-ob-action="next"]');
    if (await n.count()) { await n.click(); await page.waitForTimeout(30); } else break;
  }
  await page.waitForTimeout(150);
}
async function connect(page) {
  await page.locator('[data-tab="settings"]').click();
  await page.waitForTimeout(150);
  await page.locator('#gas-url-input').fill(GAS);
  await page.locator('#gas-token-input').fill('t');
  await page.locator('[data-action="save-gas-config"]').click();
  await page.waitForTimeout(600);
}

test.describe('v44.9 ① 機種変更した端末で接続設定を入れても、シートは消えない', () => {
  test('端末が0件のまま接続しても、シートへ書き込みに行かない', async ({ page }) => {
    const state = mockSheet(page, SHEET_WITH_DATA());
    await boot(page);
    // オンボーディングを終えただけの、記録が1件も無い新しい端末を作る
    await page.evaluate(() => { entries.length = 0; weightEntries.length = 0; mealEntries.length = 0; saveState(); });
    await page.reload();
    await page.waitForTimeout(200);
    await connect(page);

    // 【核心】この時点でシートへの書き込みが一度も起きていないこと
    expect(state.saved).toEqual([]);
    // シートに記録があることを検知して、どちらを残すか尋ねている
    const html = await page.locator('#tab-content').innerHTML();
    expect(html).toContain('すでに記録が入っています');
    expect(await page.locator('[data-action="connect-use-sheet"]').count()).toBe(1);
  });

  test('「シートの内容を取り込む」で記録が戻り、そのあとは普通に同期できる', async ({ page }) => {
    const state = mockSheet(page, SHEET_WITH_DATA());
    await boot(page);
    await page.evaluate(() => { entries.length = 0; weightEntries.length = 0; mealEntries.length = 0; saveState(); });
    await page.reload();
    await page.waitForTimeout(200);
    await connect(page);
    await page.locator('[data-action="connect-use-sheet"]').click();
    await page.waitForTimeout(600);

    const counts = await page.evaluate(() => ({ e: entries.length, w: weightEntries.length, m: mealEntries.length }));
    expect(counts).toEqual({ e: 2, w: 2, m: 1 });
    // 記録が戻ったので、以後の同期は普通に通る
    await page.evaluate(() => { weightEntries.unshift({ date: localDateStr(), weight: 78 }); saveState(); syncToSheet(); });
    await page.waitForTimeout(600);
    expect(state.saved.length).toBeGreaterThan(0);
  });

  test('「この端末の内容で上書きする」を選んだときだけ、こちらの内容が送られる', async ({ page }) => {
    const state = mockSheet(page, SHEET_WITH_DATA());
    await boot(page);
    await page.evaluate(() => {
      entries.length = 0; weightEntries.length = 0; mealEntries.length = 0;
      weightEntries.push({ date: localDateStr(), weight: 70 });
      saveState();
    });
    await page.reload();
    await page.waitForTimeout(200);
    await connect(page);
    expect(state.saved).toEqual([]);   // 選ぶまでは送らない
    await page.locator('[data-action="connect-use-local"]').click();
    await page.waitForTimeout(600);
    expect(state.saved.length).toBe(1);
    expect(state.saved[0]['体重'].rows.length).toBe(1);
  });

  test('シートが空なら、これまでどおり黙って同期してよい', async ({ page }) => {
    const state = mockSheet(page, null);
    await boot(page);
    await page.evaluate(() => { weightEntries.push({ date: localDateStr(), weight: 70 }); saveState(); });
    await page.reload();
    await page.waitForTimeout(200);
    await connect(page);
    // シートが空だったときは通常の同期(2.5秒デバウンス)に流すので、その分待つ。
    await page.waitForTimeout(SYNC_DEBOUNCE_MS + 1200);
    expect(state.saved.length).toBeGreaterThan(0);
    expect(await page.locator('[data-action="connect-use-sheet"]').count()).toBe(0);
  });
});

test.describe('v44.9 ② localStorageが壊れていても、シートを空で上書きしない', () => {
  test('読み込み失敗を検知して警告を出し、同期を止める', async ({ page }) => {
    const state = mockSheet(page, SHEET_WITH_DATA());
    await boot(page);
    await page.evaluate((gas) => {
      localStorage.setItem('training-log-config', JSON.stringify({ url: gas, token: 't', lastKnownWriteAt: null }));
    }, GAS);
    // 保存内容を壊す(iOSのストレージ破損やバージョン混在で実際に起こりうる)
    await page.evaluate(() => { localStorage.setItem('training-log-data', '{"entries":[{"broken'); });
    await page.reload();
    await page.waitForTimeout(400);

    expect(await page.evaluate(() => dataLoadFailed)).toBe(true);
    // オンボーディング画面にも、記録が無事であることが出ている
    expect(await page.locator('#app').innerHTML()).toContain('読み込めませんでした');
    // 記録を1件つけようとしても、シートは空で上書きされない
    await page.evaluate(() => { scheduleSync(); syncToSheet(); });
    await page.waitForTimeout(600);
    expect(state.saved).toEqual([]);
  });
});

test.describe('v44.9 ③ すべてのデータを削除するとき、シートをどうするか選べる', () => {
  async function setupWithData(page) {
    const state = mockSheet(page, SHEET_WITH_DATA());
    await boot(page);
    await page.evaluate(() => { weightEntries.push({ date: localDateStr(), weight: 70 }); saveState(); });
    await page.reload();
    await page.waitForTimeout(200);
    await connect(page);
    await page.waitForTimeout(300);
    // 接続直後の選択が出ていれば「この端末の内容で上書き」で普通の状態にしておく
    if (await page.locator('[data-action="connect-use-local"]').count()) {
      await page.locator('[data-action="connect-use-local"]').click();
      await page.waitForTimeout(500);
    }
    state.saved.length = 0;
    return state;
  }

  test('「端末だけ削除」ならシートには送らない', async ({ page }) => {
    const state = await setupWithData(page);
    await page.locator('[data-action="toggle-settings-section"][data-val="data"]').click();
    await page.waitForTimeout(150);
    await page.locator('[data-action="reset-show"]').click();
    await page.waitForTimeout(150);
    // 連携しているので、シートをどうするかが選択肢として出る
    expect(await page.locator('[data-action="reset-yes-keep-sheet"]').count()).toBe(1);
    expect(await page.locator('[data-action="reset-yes-with-sheet"]').count()).toBe(1);
    await page.locator('[data-action="reset-yes-keep-sheet"]').click();
    await page.waitForTimeout(600);
    expect(state.saved).toEqual([]);
  });

  test('「両方削除」を選んだときだけ、シートも空になる', async ({ page }) => {
    const state = await setupWithData(page);
    await page.locator('[data-action="toggle-settings-section"][data-val="data"]').click();
    await page.waitForTimeout(150);
    await page.locator('[data-action="reset-show"]').click();
    await page.waitForTimeout(150);
    await page.locator('[data-action="reset-yes-with-sheet"]').click();
    await page.waitForTimeout(800);
    expect(state.saved.length).toBe(1);
    expect(state.saved[0]['体重'].rows).toEqual([]);
  });
});

test.describe('v44.9 ④ 全件送り直しは確認してから', () => {
  test('「今すぐ全部を同期し直す」は、押しただけでは送信しない', async ({ page }) => {
    const state = mockSheet(page, SHEET_WITH_DATA());
    await boot(page);
    await page.evaluate(() => { weightEntries.push({ date: localDateStr(), weight: 70 }); saveState(); });
    await page.reload();
    await page.waitForTimeout(200);
    await connect(page);
    if (await page.locator('[data-action="connect-use-local"]').count()) {
      await page.locator('[data-action="connect-use-local"]').click();
      await page.waitForTimeout(500);
    }
    state.saved.length = 0;

    await page.locator('[data-action="retry-sync"]').click();
    await page.waitForTimeout(300);
    expect(state.saved).toEqual([]);
    expect(await page.locator('#tab-content').innerHTML()).toContain('シートの内容を全部置き換えます');
    await page.locator('[data-action="force-sync-yes"]').click();
    await page.waitForTimeout(700);
    expect(state.saved.length).toBe(1);
  });
});

test.describe('v44.9 ⑤ 保存できなかったことを黙って隠さない', () => {
  test('localStorageに書けないときは警告を出す', async ({ page }) => {
    await boot(page);
    await page.evaluate(() => {
      localStorage.setItem = () => { throw new Error('QuotaExceededError'); };
      saveState();
    });
    await page.waitForTimeout(200);
    expect(await page.evaluate(() => storageWriteFailed)).toBe(true);
    expect(await page.locator('#data-warning').innerHTML()).toContain('保存できませんでした');
  });
});

test.describe('v44.9 ⑥ 運動ぶんのカロリーが目標ペースに反映される', () => {
  async function targetsFor(page, minutes) {
    return await page.evaluate((min) => {
      profile = { age: 40, gender: '男性', height: 170, activity: '週1-2回', lifestyle: DEFAULT_LIFESTYLE, timeAvail: '10-15分' };
      goals = { weight: 70, weeklyFreq: 3, pace: 0.5 };
      weightEntries.length = 0; entries.length = 0; mealEntries.length = 0;
      const today = localDateStr();
      weightEntries.push({ date: today, weight: 80 });
      if (min) entries.push({ id: 'r', date: today, type: 'cardio', exercise: 'ランニング', minutes: min, createdAt: Date.now() });
      const t = getTargets();
      const e = getEffectiveCalorieTarget(today);
      return {
        needDeficit: t.needDeficit, gap: t.gapByExercise,
        burn: e.exerciseBurn, bonus: e.exerciseBonus, target: e.effectiveTarget,
        realDeficit: Math.round(t.tdee + e.exerciseBurn - e.effectiveTarget),
      };
    }, minutes);
  }

  test('運動しない日は、食事だけで作れる赤字にとどまる', async ({ page }) => {
    await boot(page);
    const r = await targetsFor(page, 0);
    expect(r.gap).toBeGreaterThan(0);          // 目安が基礎代謝で頭打ちになっている前提
    expect(r.realDeficit).toBe(r.needDeficit - r.gap);
  });

  test('少し運動した日は、その分だけ目標ペースに近づく(目標は据え置き)', async ({ page }) => {
    await boot(page);
    const none = await targetsFor(page, 0);
    const light = await targetsFor(page, 10);
    expect(light.burn).toBeGreaterThan(0);
    expect(light.burn).toBeLessThan(light.gap + 1e-9 + light.gap); // 不足分に収まる程度の運動
    expect(light.bonus).toBe(0);
    expect(light.target).toBe(none.target);                    // 食べてよい量は増えない
    expect(light.realDeficit).toBe(none.realDeficit + light.burn); // 赤字はその分だけ増える
  });

  test('しっかり運動した日は、不足分を埋めたうえで残りが上乗せされ、目標ペースちょうどになる', async ({ page }) => {
    await boot(page);
    const hard = await targetsFor(page, 60);
    expect(hard.bonus).toBe(hard.burn - hard.gap);
    expect(hard.realDeficit).toBe(hard.needDeficit);   // ← v44.8までは埋まらなかった部分
  });

  test('画面の説明文が、実際の計算と食い違わない', async ({ page }) => {
    await boot(page);
    await targetsFor(page, 10);
    const light = await page.evaluate(() => exerciseTargetNoteText_(getEffectiveCalorieTarget(localDateStr())));
    expect(light).toContain('穴埋め');
    await targetsFor(page, 60);
    const hard = await page.evaluate(() => exerciseTargetNoteText_(getEffectiveCalorieTarget(localDateStr())));
    expect(hard).toContain('残り');
    expect(hard).toContain('目標に加算');
  });
});
