// 開発者向け: 体組成カードに体脂肪率の推移グラフを追加した回帰テストです(v44.4)。
// アプリの利用には不要なファイルです(無視して構いません)。
//   npx playwright test tests/bodyfatchart.spec.js
//
// 背景: 「体重、体脂肪率のグラフを追加して」というご要望。体重グラフに体脂肪率を
// 重ねる案(1グラフに2軸)も検討したが、単位(kg / %)が違う2本を同じ軸に重ねると
// 見た目の傾きが実際の相関を表さず読み違えやすいため、体重グラフとは別に、
// 体組成カード(🧬)の中に体脂肪率だけの折れ線グラフを追加する形にした。
const { test, expect } = require('@playwright/test');
const path = require('path');

const APP = () => 'file://' + path.resolve(__dirname, '../index.html');

async function boot(page) {
  await page.goto(APP());
  for (let i = 0; i < 8; i++) {
    const f = page.locator('[data-ob-action="finish"]');
    if (await f.count()) { await f.click(); break; }
    const n = page.locator('[data-ob-action="next"]');
    if (await n.count()) { await n.click(); await page.waitForTimeout(30); } else break;
  }
  await page.waitForTimeout(120);
}
async function seed(page, entries) {
  await page.evaluate((entries) => {
    profile = { age: 48, gender: '男性', height: 168, activity: '週1-2回', lifestyle: 'デスクワーク中心', timeAvail: '10-15分' };
    goals = { weight: 70, weeklyFreq: 3, paceKgPerWeek: 0.25 };
    weightEntries.length = 0;
    entries.forEach(e => weightEntries.push(e));
    saveState();
  }, entries);
  await page.reload();
  await page.waitForTimeout(220);
}
const today = () => new Date().toISOString().slice(0, 10);
const daysAgo = n => new Date(Date.now() - n * 86400000).toISOString().slice(0, 10);

// #tab-content 内の .card のうち、見出しに heading を含むものの innerHTML を返す。
// 「体組成」は「体重を記録」カードの文脈には出てこないはずだが、:has-text は
// 想定より広く一致することがあるため、DOM側で確実に絞り込む。
async function getCardHtml(page, heading) {
  return page.evaluate((heading) => {
    const cards = Array.from(document.querySelectorAll('#tab-content .card'));
    const card = cards.find(c => c.querySelector('.section-title')?.textContent.includes(heading));
    return card ? card.innerHTML : null;
  }, heading);
}

test.describe('training-log v44.4 — 体脂肪率の推移グラフ', () => {
  test('体脂肪率が1件も無ければ、これまでどおり案内文だけでグラフは出ない', async ({ page }) => {
    await boot(page);
    await seed(page, [{ date: today(), weight: 78 }]);
    await page.locator('[data-tab="weight"]').click();
    await page.waitForTimeout(150);
    const html = await getCardHtml(page, '体組成');
    expect(html).toContain('体脂肪率を記録すると');
    expect(html).not.toContain('体脂肪率の推移');
    expect(html).not.toContain('<svg');
  });

  test('体脂肪率が2件以上あれば、体組成カードの中にグラフが出る', async ({ page }) => {
    await boot(page);
    await seed(page, [
      { date: daysAgo(10), weight: 80, bodyFat: 31 },
      { date: today(),     weight: 78, bodyFat: 29 },
    ]);
    await page.locator('[data-tab="weight"]').click();
    await page.waitForTimeout(150);
    const html = await getCardHtml(page, '体組成');
    expect(html).toContain('体脂肪率の推移');
    expect((html.match(/<svg/g) || []).length).toBe(1);
    // 現在値は数値としてもそのまま出る(色だけに頼らない)
    expect(html).toContain('29.0');
  });

  test('体重グラフと体脂肪率グラフは別々のSVGで、1つのグラフに2軸で重ねてはいない', async ({ page }) => {
    await boot(page);
    await seed(page, [
      { date: daysAgo(10), weight: 80, bodyFat: 31 },
      { date: today(),     weight: 78, bodyFat: 29 },
    ]);
    await page.locator('[data-tab="weight"]').click();
    await page.waitForTimeout(150);
    // 体重の推移カードに1つ、体組成カードに1つ、計2つの独立したSVG
    const svgCount = await page.locator('#tab-content svg').count();
    expect(svgCount).toBe(2);
  });

  test('記録が7日以上あると7日平均の線になり、1週間の変化が表示される', async ({ page }) => {
    await boot(page);
    const entries = [];
    for (let i = 9; i >= 0; i--) entries.push({ date: daysAgo(i), weight: 78, bodyFat: 30 - i * 0.2 });
    await seed(page, entries);
    await page.locator('[data-tab="weight"]').click();
    await page.waitForTimeout(150);
    const html = await getCardHtml(page, '体組成');
    expect(html).toContain('7日平均');
    expect(html).toContain('1週間');
  });

  test('体脂肪率が1件だけなら、グラフの代わりに案内文が出る(体重グラフと同じ挙動)', async ({ page }) => {
    await boot(page);
    await seed(page, [{ date: today(), weight: 78, bodyFat: 29 }]);
    await page.locator('[data-tab="weight"]').click();
    await page.waitForTimeout(150);
    const html = await getCardHtml(page, '体組成');
    expect(html).toContain('データが2件以上になるとグラフが表示されます');
  });
});
