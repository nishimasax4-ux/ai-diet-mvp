// 開発者向け: 有酸素運動に「ジョギング」を追加した回帰テストです(v44.7)。
// アプリの利用には不要なファイルです(無視して構いません)。
//   npx playwright test tests/jogging.spec.js
//
// 背景: 「ジョギングはランニングでいい?」というご質問。ランニング(MET8)で
// 代用すると消費カロリーを1〜2割ほど多く見積もることになるため、ジョギング用に
// MET7の項目を追加した(Compendium of Physical Activitiesの
// "running, jogging, general"目安)。
const { test, expect } = require('@playwright/test');
const path = require('path');
const APP = () => 'file://' + path.resolve(__dirname, '../index.html');

async function boot(page) {
  await page.goto(APP());
  for (let i = 0; i < 8; i++) {
    const f = page.locator('[data-ob-action="finish"]');
    if (await f.count()) { await f.click(); break; }
    const n = page.locator('[data-ob-action="next"]');
    if (await n.count()) { await n.click(); await page.waitForTimeout(30); } else break;
  }
  await page.waitForTimeout(120);
}
async function openCardio(page) {
  await page.locator('[data-tab="training"]').click();
  await page.waitForTimeout(150);
  await page.locator('[data-action="select-training-type"][data-val="cardio"]').click();
  await page.waitForTimeout(150);
}
const today = () => new Date().toISOString().slice(0, 10);

test.describe('training-log v44.7 — 有酸素運動「ジョギング」の追加', () => {
  test('有酸素の種目チップに「ジョギング」が選べる', async ({ page }) => {
    await boot(page);
    await openCardio(page);
    const labels = await page.locator('#cardio-buttons .chip').allTextContents();
    expect(labels).toContain('ジョギング');
  });

  test('ジョギングのMETはランニングより低く(7)、同じ時間でも消費カロリーが少なく計算される', async ({ page }) => {
    await boot(page);
    const [runBurn, jogBurn] = await page.evaluate(() => [
      estimateEntryBurn_({ type: 'cardio', exercise: 'ランニング', minutes: 30 }, 70),
      estimateEntryBurn_({ type: 'cardio', exercise: 'ジョギング', minutes: 30 }, 70),
    ]);
    expect(jogBurn).toBeLessThan(runBurn);
    expect(jogBurn).toBe(Math.round((7 * 3.5 * 70 / 200) * 30));
  });

  test('ジョギングを記録すると、履歴にMET7で計算した概算カロリーが表示される', async ({ page }) => {
    await boot(page);
    await page.evaluate((d) => {
      weightEntries.length = 0;
      weightEntries.push({ date: d, weight: 70 });
      entries.length = 0;
      entries.push({ id: 'j1', date: d, type: 'cardio', exercise: 'ジョギング', minutes: 30, createdAt: Date.now() });
      saveState();
    }, today());
    await page.reload();
    await page.waitForTimeout(200);
    await page.locator('[data-tab="training"]').click();
    await page.waitForTimeout(200);
    const html = await page.locator('#history-section').innerHTML();
    const expected = Math.round((7 * 3.5 * 70 / 200) * 30);
    expect(html).toContain('ジョギング');
    expect(html).toContain(`約${expected}kcal`);
  });
});
