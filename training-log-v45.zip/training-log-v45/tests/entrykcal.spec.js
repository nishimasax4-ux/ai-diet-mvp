// 開発者向け: 運動の履歴に「1件ごとの概算消費カロリー」を added した回帰テストです(v44.6)。
// アプリの利用には不要なファイルです(無視して構いません)。
//   npx playwright test tests/entrykcal.spec.js
//
// 背景:「運動ごとの消費カロリーの表示が欲しい」というご要望。以前は日ごとの
// 合計(進捗グラフ)しか出ておらず、1件1件の記録にはカロリーが出ていなかった。
// 食事の履歴には既に (◯◯kcal) が出ているので、運動もそれに揃える形にした。
const { test, expect } = require('@playwright/test');
const path = require('path');

const APP = () => 'file://' + path.resolve(__dirname, '../index.html');

async function boot(page) {
  await page.goto(APP());
  for (let i = 0; i < 8; i++) {
    const f = page.locator('[data-ob-action="finish"]');
    if (await f.count()) { await f.click(); break; }
    const n = page.locator('[data-ob-action="next"]');
    if (await n.count()) { await n.click(); await page.waitForTimeout(30); } else break;
  }
  await page.waitForTimeout(120);
}
const today = () => new Date().toISOString().slice(0, 10);

test.describe('training-log v44.6 — 運動ごとの概算消費カロリー', () => {
  test('筋トレは1セットあたり固定の目安カロリーが表示される', async ({ page }) => {
    await boot(page);
    await page.evaluate((d) => {
      entries.length = 0;
      entries.push({ id: 'e1', date: d, type: 'strength', part: '胸', exercise: 'ベンチプレス', reps: 10, weight: 60, createdAt: Date.now() });
      saveState();
    }, today());
    await page.reload();
    await page.waitForTimeout(200);
    await page.locator('[data-tab="training"]').click();
    await page.waitForTimeout(200);
    const html = await page.locator('#history-section').innerHTML();
    expect(html).toContain('ベンチプレス');
    // STRENGTH_KCAL_PER_SET = 10
    expect(html).toContain('約10kcal');
  });

  test('有酸素は体重とMETsから計算した概算カロリーが表示される', async ({ page }) => {
    await boot(page);
    await page.evaluate((d) => {
      weightEntries.length = 0;
      weightEntries.push({ date: d, weight: 70 });
      entries.length = 0;
      entries.push({ id: 'e2', date: d, type: 'cardio', exercise: 'ランニング', minutes: 30, createdAt: Date.now() });
      saveState();
    }, today());
    await page.reload();
    await page.waitForTimeout(200);
    await page.locator('[data-tab="training"]').click();
    await page.waitForTimeout(200);
    const html = await page.locator('#history-section').innerHTML();
    const expected = await page.evaluate(() => estimateEntryBurn_({ type: 'cardio', exercise: 'ランニング', minutes: 30 }, 70));
    expect(html).toContain(`約${expected}kcal`);
  });

  test('体重が未記録でも(仮の値で)概算が表示される', async ({ page }) => {
    await boot(page);
    await page.evaluate((d) => {
      weightEntries.length = 0;
      entries.length = 0;
      entries.push({ id: 'e3', date: d, type: 'cardio', exercise: 'ウォーキング', minutes: 20, createdAt: Date.now() });
      saveState();
    }, today());
    await page.reload();
    await page.waitForTimeout(200);
    await page.locator('[data-tab="training"]').click();
    await page.waitForTimeout(200);
    const html = await page.locator('#history-section').innerHTML();
    expect(html).toMatch(/約\d+kcal/);
  });

  test('カレンダー表示の日別詳細にも同じカロリーが出る(表示の食い違いが無い)', async ({ page }) => {
    await boot(page);
    await page.evaluate((d) => {
      weightEntries.length = 0;
      weightEntries.push({ date: d, weight: 70 });
      entries.length = 0;
      entries.push({ id: 'e4', date: d, type: 'strength', part: '脚', exercise: 'スクワット', reps: 8, weight: 80, createdAt: Date.now() });
      saveState();
    }, today());
    await page.reload();
    await page.waitForTimeout(200);
    await page.locator('[data-tab="training"]').click();
    await page.waitForTimeout(200);
    await page.locator('[data-action="view-calendar"]').click();
    await page.waitForTimeout(150);
    const html = await page.locator('#history-section').innerHTML();
    expect(html).toContain('スクワット');
    expect(html).toContain('約10kcal');
  });
});
