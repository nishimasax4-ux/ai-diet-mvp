// 開発者向け: 「今日」タブの週間トレーニング ○/○回 の回帰テストです(v44.3)。
// アプリの利用には不要なファイルです(無視して構いません)。
//   npx playwright test tests/weekmeter.spec.js
//
// 背景: 「毎日運動しているのに5/7はおかしい」という報告(v44.2)。実際には
// weekBuckets() のカウントは正しく(有酸素も含めて数えている)、週の途中は
// まだ来ていない曜日を数えられないぶん分母より小さく出るのが「正しい」動作
// だった。誤解を防ぐため、週が終わっていない場合に「今週はあと○日」という
// 注記を出すようにした。このテストはその注記の有無と、weekBuckets/
// daysLeftInWeek の日数計算そのものを検証する。
const { test, expect } = require('@playwright/test');
const path = require('path');

const APP = 'file://' + path.resolve(__dirname, '../index.html');

async function finishOnboarding(page) {
  for (let i = 0; i < 8; i++) {
    const fin = page.locator('[data-ob-action="finish"]');
    if (await fin.count()) { await fin.click(); break; }
    const next = page.locator('[data-ob-action="next"]');
    if (await next.count()) { await next.click(); await page.waitForTimeout(30); } else break;
  }
}

// 2026-09-05 は土曜日。月曜始まりの今週は 8/31(月)〜9/6(日)。
// 土曜日時点で経過しているのは月〜土の6日、日曜はまだ来ていない。
const SATURDAY = '2026-09-05T09:00:00';
// 2026-09-06 は日曜日。この週の最終日 = 週は終わっている(残り0日)。
const SUNDAY = '2026-09-06T09:00:00';

async function seedTrainingEveryDayThisWeekUpTo(page, lastDateStr, freq) {
  await page.evaluate(({ lastDateStr, freq }) => {
    const entries = [];
    // 8/31(月)〜lastDateStr まで、毎日1件ずつ有酸素運動を記録(=「毎日運動している」を再現)。
    const start = new Date('2026-08-31T00:00:00');
    const last = new Date(lastDateStr + 'T00:00:00');
    for (let d = new Date(start); d <= last; d.setDate(d.getDate() + 1)) {
      const y = d.getFullYear(), m = String(d.getMonth()+1).padStart(2,'0'), day = String(d.getDate()).padStart(2,'0');
      entries.push({ id: `${y}${m}${day}`, date: `${y}-${m}-${day}`, type: 'cardio', exercise: 'ウォーキング', minutes: 30 });
    }
    const st = JSON.parse(localStorage.getItem('training-log-data') || '{}');
    st.entries = entries;
    st.goals = Object.assign({ weight: 70, weeklyFreq: freq }, st.goals, { weeklyFreq: freq });
    localStorage.setItem('training-log-data', JSON.stringify(st));
  }, { lastDateStr, freq });
}

test.describe('週間トレーニング○/○回の週途中の見せ方', () => {
  test('土曜日・毎日運動していれば6/7で、「今週はあと1日」の注記が出る', async ({ page }) => {
    await page.clock.install({ time: new Date(SATURDAY) });
    await page.goto(APP);
    await finishOnboarding(page);
    await seedTrainingEveryDayThisWeekUpTo(page, '2026-09-05', 7);
    await page.reload();
    await page.waitForTimeout(300);
    await finishOnboarding(page);

    const daysLeft = await page.evaluate(() => daysLeftInWeek());
    expect(daysLeft).toBe(1); // 日曜がまだ残っている

    const thisWeek = await page.evaluate(() => weekBuckets(1)[0]);
    expect(thisWeek.count).toBe(6); // 月〜土=6日、全部記録済み(有酸素も数えている)

    const body = await page.locator('#app').innerText();
    expect(body).toContain('6/7回');
    expect(body).toContain('今週(月曜始まり)はあと1日あります');
  });

  test('日曜日(週の最終日)なら注記は出ない', async ({ page }) => {
    await page.clock.install({ time: new Date(SUNDAY) });
    await page.goto(APP);
    await finishOnboarding(page);
    await seedTrainingEveryDayThisWeekUpTo(page, '2026-09-06', 7);
    await page.reload();
    await page.waitForTimeout(300);
    await finishOnboarding(page);

    const daysLeft = await page.evaluate(() => daysLeftInWeek());
    expect(daysLeft).toBe(0);

    const thisWeek = await page.evaluate(() => weekBuckets(1)[0]);
    expect(thisWeek.count).toBe(7); // 月〜日、全部記録済みで目標達成

    const body = await page.locator('#app').innerText();
    expect(body).toContain('7/7回');
    expect(body).not.toContain('今週(月曜始まり)はあと');
  });

  test('週の途中でも目標をすでに達成していれば注記は出ない', async ({ page }) => {
    await page.clock.install({ time: new Date(SATURDAY) });
    await page.goto(APP);
    await finishOnboarding(page);
    // 週3回が目標で、月〜土のうち3日しか記録していなくても目標達成扱い。
    await seedTrainingEveryDayThisWeekUpTo(page, '2026-09-02', 3); // 月・火・水のみ
    await page.reload();
    await page.waitForTimeout(300);
    await finishOnboarding(page);

    const thisWeek = await page.evaluate(() => weekBuckets(1)[0]);
    expect(thisWeek.count).toBe(3);

    const body = await page.locator('#app').innerText();
    expect(body).toContain('3/3回');
    expect(body).not.toContain('今週(月曜始まり)はあと');
  });
});
