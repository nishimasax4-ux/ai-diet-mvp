// 開発者向け: v43で追加した「写真から記録」の回帰テストです。
//   npx playwright test tests/photo.spec.js
const { test, expect } = require('@playwright/test');
const path = require('path');
const APP = () => 'file://' + path.resolve(__dirname, '../index.html');

// 1x1の赤いJPEGでは料理として意味がないが、経路(縮小→送信→表示)の確認には十分。
// 実際に縮小されるかを見たいので、少し大きめのPNGをcanvasで作って渡す。
async function boot(page) {
  await page.goto(APP());
  for (let i = 0; i < 8; i++) {
    const f = page.locator('[data-ob-action="finish"]');
    if (await f.count()) { await f.click(); break; }
    const n = page.locator('[data-ob-action="next"]');
    if (await n.count()) { await n.click(); await page.waitForTimeout(30); } else break;
  }
  await page.waitForTimeout(120);
}
async function connect(page) {
  await page.evaluate(() => {
    gasConfig = { url: 'https://script.google.com/macros/s/fake/exec', token: 't', lastKnownWriteAt: null };
    saveConfig(); renderApp();
  });
}
// 2000x1500の画像を作ってファイル入力に流し込む
async function pickPhoto(page) {
  const buf = await page.evaluate(async () => {
    const c = document.createElement('canvas');
    c.width = 2000; c.height = 1500;
    const g = c.getContext('2d');
    g.fillStyle = '#c33'; g.fillRect(0, 0, 2000, 1500);
    const b = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.9));
    return Array.from(new Uint8Array(await b.arrayBuffer()));
  });
  await page.setInputFiles('#photo-input', {
    name: 'meal.jpg', mimeType: 'image/jpeg', buffer: Buffer.from(buf),
  });
  await page.waitForTimeout(900);
}

test.describe('training-log v43 — 写真から記録', () => {
  test('写真は縮小してから送られ、生の写真をそのまま送らない', async ({ page }) => {
    let sent = null;
    await page.route('https://script.google.com/macros/**', (route, request) => {
      const body = JSON.parse(request.postData() || '{}');
      if (body.action === 'aiVision') sent = body;
      route.fulfill({ status: 200, contentType: 'application/json',
        body: JSON.stringify({ status: 'ok', text: JSON.stringify({ foods: [{ name: 'テスト料理', kcal: 500, protein: 20, fat: 15, carb: 60 }] }) }) });
    });
    await boot(page); await connect(page);
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    await pickPhoto(page);

    expect(sent).not.toBeNull();
    expect(sent.mimeType).toBe('image/jpeg');
    // 2000x1500の写真が、長辺768pxまで縮小されていること(=送信量が小さいこと)
    const bytes = Math.round(sent.imageBase64.length * 3 / 4);
    expect(bytes).toBeLessThan(200 * 1024);
    // data: のプレフィックスは付けずに送る
    expect(sent.imageBase64.startsWith('data:')).toBe(false);
  });

  test('判定結果が候補として並び、タップで入力欄に入る(記録はされない)', async ({ page }) => {
    await page.route('https://script.google.com/macros/**', (route, request) => {
      const body = JSON.parse(request.postData() || '{}');
      const out = body.action === 'aiVision'
        ? { status: 'ok', text: JSON.stringify({ foods: [{ name: '鶏の唐揚げ(5個)', kcal: 480, protein: 28, fat: 30, carb: 20 }] }) }
        : { status: 'ok', payload: {}, lastWriteAt: null, written: 0 };
      route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(out) });
    });
    await boot(page); await connect(page);
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    const before = await page.evaluate(() => mealEntries.length);
    await pickPhoto(page);

    const html = await page.locator('#tab-content').innerHTML();
    expect(html).toContain('鶏の唐揚げ(5個)');
    expect(html).toContain('AIの概算');

    await page.locator('[data-action="use-meal-suggestion"][data-name="鶏の唐揚げ(5個)"]').click();
    await page.waitForTimeout(300);
    expect(await page.locator('#meal-name-input').inputValue()).toBe('鶏の唐揚げ(5個)');
    expect(await page.locator('#meal-cal-input').inputValue()).toBe('480');
    // 本人が「＋ 記録する」を押すまでは記録されない
    expect(await page.evaluate(() => mealEntries.length)).toBe(before);
  });

  test('マスタに同じ名前があれば、AIの概算ではなく登録済みの値を使う', async ({ page }) => {
    await page.route('https://script.google.com/macros/**', (route, request) => {
      const body = JSON.parse(request.postData() || '{}');
      const out = body.action === 'aiVision'
        ? { status: 'ok', text: JSON.stringify({ foods: [{ name: '鶏胸肉のサラダ', kcal: 999, protein: 1, fat: 1, carb: 1 }] }) }
        : { status: 'ok', payload: {}, lastWriteAt: null, written: 0 };
      route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(out) });
    });
    await boot(page); await connect(page);
    await page.evaluate(() => {
      mealMaster.push({ id: uid(), name: '鶏胸肉のサラダ', calories: 320, protein: 35, fat: 8, carb: 12 });
      saveState();
    });
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    await pickPhoto(page);

    const res = await page.evaluate(() => photoResults);
    expect(res[0].source).toBe('master');
    expect(res[0].kcal).toBe(320);      // AIの999ではなく、自分の登録値
    expect(await page.locator('#tab-content').innerHTML()).toContain('登録済みの値');
  });

  test('内蔵辞書に同じ名前があれば、辞書の値を使う', async ({ page }) => {
    await page.route('https://script.google.com/macros/**', (route, request) => {
      const body = JSON.parse(request.postData() || '{}');
      const out = body.action === 'aiVision'
        ? { status: 'ok', text: JSON.stringify({ foods: [{ name: 'ご飯(茶碗1杯)', kcal: 999, protein: 1, fat: 1, carb: 1 }] }) }
        : { status: 'ok', payload: {}, lastWriteAt: null, written: 0 };
      route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(out) });
    });
    await boot(page); await connect(page);
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    await pickPhoto(page);
    const res = await page.evaluate(() => photoResults);
    expect(res[0].source).toBe('dict');
    expect(res[0].kcal).toBe(252);
  });

  test('似ているだけの名前では、勝手に登録値へ置き換えない', async ({ page }) => {
    await page.route('https://script.google.com/macros/**', (route, request) => {
      const body = JSON.parse(request.postData() || '{}');
      const out = body.action === 'aiVision'
        ? { status: 'ok', text: JSON.stringify({ foods: [{ name: '唐揚げ弁当(大盛)', kcal: 850, protein: 30, fat: 35, carb: 95 }] }) }
        : { status: 'ok', payload: {}, lastWriteAt: null, written: 0 };
      route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(out) });
    });
    await boot(page); await connect(page);
    await page.evaluate(() => {
      mealMaster.push({ id: uid(), name: '唐揚げ', calories: 200, protein: 12, fat: 12, carb: 8 });
      saveState();
    });
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    await pickPhoto(page);
    const res = await page.evaluate(() => photoResults);
    // 分量の違う別物なので、AIの値をそのまま使う
    expect(res[0].source).toBe('ai');
    expect(res[0].kcal).toBe(850);
  });

  test('食事が写っていない場合は、その旨を案内する', async ({ page }) => {
    await page.route('https://script.google.com/macros/**', (route, request) => {
      const body = JSON.parse(request.postData() || '{}');
      const out = body.action === 'aiVision'
        ? { status: 'ok', text: JSON.stringify({ foods: [] }) }
        : { status: 'ok', payload: {}, lastWriteAt: null, written: 0 };
      route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(out) });
    });
    await boot(page); await connect(page);
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    await pickPhoto(page);
    expect(await page.locator('#tab-content').innerHTML()).toContain('判別できませんでした');
  });

  test('接続設定が無ければ、写真を送らずに案内を出す', async ({ page }) => {
    let called = false;
    await page.route('https://script.google.com/macros/**', (route) => { called = true; route.abort(); });
    await boot(page);
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    await pickPhoto(page);
    expect(called).toBe(false);
    expect(await page.locator('#tab-content').innerHTML()).toContain('接続先URLとトークンを登録');
  });

  test('写真がAIへ送られることを画面に明示している', async ({ page }) => {
    await boot(page);
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    const html = await page.locator('#tab-content').innerHTML();
    expect(html).toContain('写真から記録');
    expect(html).toContain('AI');
    expect(html).toContain('保存しません');
  });
});
