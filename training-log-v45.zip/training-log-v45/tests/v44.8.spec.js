// 開発者向け: v44.8で入れた7件のUI変更の回帰テストです。
// GitHub Pagesへの公開やアプリの利用には不要なファイルです(無視して構いません)。
//   npx playwright test tests/v44.8.spec.js
//
// 対象(ユーザーからのご要望①〜⑦):
//   ① 今日タブの連続記録日数を「昨日まで」で数える
//   ② 「今日のおすすめ食事」を今日タブ→食事タブへ移動
//   ③ 「昨日の記録をコピー」を今日タブから廃止し、食事・運動タブへ分けて移動
//   ④ 今日タブの「AIのひとこと」から体調選択ボタンを廃止し、記録ベースの助言に変更
//   ⑤ マスタ登録(種目・食事)を分割し、編集(修正)できるようにする
//   ⑥ 運動・食事の履歴を、合計は残したままアコーディオン(既定は閉じる)にする
//   ⑦ Apps Script接続設定(URL・トークン)を、保存後は伏せて表示する
const { test, expect } = require('@playwright/test');
const path = require('path');
const APP = () => 'file://' + path.resolve(__dirname, '../index.html');

async function boot(page) {
  await page.goto(APP());
  for (let i = 0; i < 8; i++) {
    const f = page.locator('[data-ob-action="finish"]');
    if (await f.count()) { await f.click(); break; }
    const n = page.locator('[data-ob-action="next"]');
    if (await n.count()) { await n.click(); await page.waitForTimeout(30); } else break;
  }
  await page.waitForTimeout(120);
}
const today = () => new Date().toISOString().slice(0, 10);
const yesterday = () => new Date(Date.now() - 86400000).toISOString().slice(0, 10);
const dayBefore = () => new Date(Date.now() - 2 * 86400000).toISOString().slice(0, 10);

test.describe('training-log v44.8 — ①連続日数は昨日まで', () => {
  test('今日はまだ記録が無くても、昨日までの連続日数がそのまま表示される', async ({ page }) => {
    await boot(page);
    await page.evaluate(({ y, d2 }) => {
      entries.length = 0;
      entries.push({ id: 'e1', date: y, type: 'cardio', exercise: 'ランニング', minutes: 20, createdAt: Date.now() });
      entries.push({ id: 'e2', date: d2, type: 'cardio', exercise: 'ランニング', minutes: 20, createdAt: Date.now() });
      saveState();
    }, { y: yesterday(), d2: dayBefore() });
    await page.reload();
    await page.waitForTimeout(200);
    await page.locator('[data-tab="today"]').click();
    await page.waitForTimeout(150);
    const html = await page.locator('#tab-content').innerHTML();
    expect(html).toContain('日連続(昨日まで)');
    // 今日の記録が無いのに0にリセットされていないこと
    const streak = await page.evaluate(() => calcStreak(entries, yesterdayDateStr()));
    expect(streak).toBe(2);
    expect(html).toMatch(/>2<\/span>\s*<span class="muted">日連続\(昨日まで\)/);
  });
});

test.describe('training-log v44.8 — ②おすすめ食事は食事タブへ', () => {
  test('今日タブには「今日のおすすめ食事」が出ない', async ({ page }) => {
    await boot(page);
    await page.evaluate(() => {
      profile = { age: 40, gender: '男性', height: 170, activity: '週1-2回', lifestyle: DEFAULT_LIFESTYLE, timeAvail: '10-15分' };
      goals = { weight: 70, weeklyFreq: 3 };
      weightEntries.length = 0;
      weightEntries.push({ date: localDateStr(), weight: 75 });
      saveState();
    });
    await page.reload();
    await page.waitForTimeout(200);
    await page.locator('[data-tab="today"]').click();
    await page.waitForTimeout(150);
    expect(await page.locator('#tab-content').innerHTML()).not.toContain('今日のおすすめ食事');
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    expect(await page.locator('#tab-content').innerHTML()).toContain('今日のおすすめ食事');
  });
});

test.describe('training-log v44.8 — ③昨日の記録コピーは食事・運動タブへ分割', () => {
  test('今日タブに「昨日の記録をコピー」カードは無い', async ({ page }) => {
    await boot(page);
    await page.evaluate((y) => {
      entries.push({ id: 'e1', date: y, type: 'cardio', exercise: 'ランニング', minutes: 20, createdAt: Date.now() });
      mealEntries.push({ id: 'm1', date: y, mealType: '朝食', text: '納豆', calories: 100, createdAt: Date.now() });
      saveState();
    }, yesterday());
    await page.reload();
    await page.waitForTimeout(200);
    await page.locator('[data-tab="today"]').click();
    await page.waitForTimeout(150);
    const html = await page.locator('#tab-content').innerHTML();
    expect(html).not.toContain('昨日の記録をコピー');
    expect(await page.locator('[data-action="copy-yesterday"]').count()).toBe(0);
  });

  test('運動タブでは、昨日の運動だけをコピーできる', async ({ page }) => {
    await boot(page);
    await page.evaluate((y) => {
      entries.push({ id: 'e1', date: y, type: 'cardio', exercise: 'ランニング', minutes: 20, createdAt: Date.now() });
      saveState();
    }, yesterday());
    await page.reload();
    await page.waitForTimeout(200);
    await page.locator('[data-tab="training"]').click();
    await page.waitForTimeout(150);
    expect(await page.locator('#tab-content').innerHTML()).toContain('昨日の運動をコピー');
    const before = await page.evaluate(() => entries.length);
    await page.locator('[data-action="copy-yesterday-training"]').click();
    await page.waitForTimeout(150);
    const after = await page.evaluate(() => entries.filter(e => e.date === localDateStr()).length);
    expect(await page.evaluate(() => entries.length)).toBe(before + 1);
    expect(after).toBe(1);
  });

  test('食事タブでは、区分ごとのコピーと「まとめてコピー」ができる', async ({ page }) => {
    await boot(page);
    await page.evaluate((y) => {
      mealEntries.push({ id: 'm1', date: y, mealType: '朝食', text: '納豆', calories: 100, createdAt: Date.now() });
      mealEntries.push({ id: 'm2', date: y, mealType: '夕食', text: '焼き魚', calories: 300, createdAt: Date.now() });
      saveState();
    }, yesterday());
    await page.reload();
    await page.waitForTimeout(200);
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    const html = await page.locator('#tab-content').innerHTML();
    expect(html).toContain('昨日の食事をコピー');
    expect(await page.locator('[data-action="copy-yesterday-meal"][data-val="朝食"]').count()).toBe(1);
    await page.locator('[data-action="copy-yesterday-meals-all"]').click();
    await page.waitForTimeout(150);
    const todayMeals = await page.evaluate(() => mealEntries.filter(m => m.date === localDateStr()).map(m => m.mealType).sort());
    expect(todayMeals).toEqual(['夕食', '朝食'].sort());
  });
});

test.describe('training-log v44.8 — ④体調ボタン廃止・記録ベースのAIひとこと', () => {
  test('今日タブに体調選択ボタンは無い', async ({ page }) => {
    await boot(page);
    await page.locator('[data-tab="today"]').click();
    await page.waitForTimeout(150);
    const html = await page.locator('#tab-content').innerHTML();
    expect(await page.locator('[data-action="set-mood"]').count()).toBe(0);
    expect(html).not.toContain('疲れた');
    expect(html).not.toContain('元気');
    // 「AIのひとこと」カード自体は引き続きある
    expect(html).toContain('AIのひとこと');
  });

  test('AIへ送る要約(buildAdviceContext)に「今日の調子」は含まれない', async ({ page }) => {
    await boot(page);
    const json = await page.evaluate(() => JSON.stringify(buildAdviceContext()));
    expect(json).not.toContain('今日の調子');
  });

  test('generateDailyAdviceは、直近の運動継続や種目名など記録内容に触れる', async ({ page }) => {
    await boot(page);
    await page.evaluate((y) => {
      const mk = (d) => ({ id: 'x' + d, date: d, type: 'strength', part: '脚', exercise: 'スクワット', reps: 10, weight: 40, createdAt: Date.now() });
      entries.push(mk(y));
      entries.push(mk(new Date(Date.now() - 2 * 86400000).toISOString().slice(0, 10)));
      entries.push(mk(new Date(Date.now() - 3 * 86400000).toISOString().slice(0, 10)));
      saveState();
    }, yesterday());
    await page.reload();
    await page.waitForTimeout(200);
    const advice = await page.evaluate(() => generateDailyAdvice());
    expect(advice).toContain('3日連続');
    expect(advice).toContain('スクワット');
  });

  test('pickWorkoutは引数なしで、利用可能時間だけから提案を決める', async ({ page }) => {
    await boot(page);
    const w = await page.evaluate(() => {
      profile.timeAvail = '5-10分';
      return pickWorkout();
    });
    expect(w).toHaveProperty('displayName');
    expect(w).toHaveProperty('intensity');
  });
});

test.describe('training-log v44.8 — ⑤マスタ管理の分割と編集', () => {
  async function openSettings(page) {
    await page.locator('[data-tab="settings"]').click();
    await page.waitForTimeout(150);
  }

  test('設定タブで、種目マスタと食事マスタが別々の折りたたみセクションになっている', async ({ page }) => {
    await boot(page);
    await openSettings(page);
    const html = await page.locator('#tab-content').innerHTML();
    expect(html).toContain('🏋️ 種目マスタ');
    expect(html).toContain('🍽️ 食事マスタ');
    expect(await page.locator('#settings-section-masterExercise').count()).toBe(1);
    expect(await page.locator('#settings-section-masterMeal').count()).toBe(1);
    // 既定では閉じている
    expect(await page.locator('#settings-section-masterExercise')).toHaveClass(/hidden/);
  });

  test('種目マスタの項目を✏️で編集できる(名前・部位)', async ({ page }) => {
    await boot(page);
    await openSettings(page);
    await page.locator('[data-action="toggle-settings-section"][data-val="masterExercise"]').click();
    await page.waitForTimeout(150);
    await page.locator('#master-ex-name-input').fill('レッグプレスマシン');
    await page.locator('[data-action="add-exercise-master"]').click();
    await page.waitForTimeout(150);
    await page.locator('[data-action="open-edit-exercise-master"]').first().click();
    await page.waitForTimeout(150);
    await page.locator('[data-edit-action="set-part"][data-val="脚"]').click();
    await page.locator('#edit-master-name').fill('レッグプレス(修正後)');
    await page.locator('[data-edit-action="save"]').click();
    await page.waitForTimeout(150);
    const item = await page.evaluate(() => exerciseMaster.find(x => x.name === 'レッグプレス(修正後)'));
    expect(item).toBeTruthy();
    expect(item.part).toBe('脚');
  });

  test('食事マスタの項目を✏️で編集できる(名前・カロリー等)', async ({ page }) => {
    await boot(page);
    await openSettings(page);
    await page.locator('[data-action="toggle-settings-section"][data-val="masterMeal"]').click();
    await page.waitForTimeout(150);
    await page.locator('#master-meal-name-input').fill('鶏胸肉のサラダ');
    await page.locator('#master-meal-cal-input').fill('300');
    await page.locator('[data-action="add-meal-master"]').click();
    await page.waitForTimeout(150);
    await page.locator('[data-action="open-edit-meal-master"]').first().click();
    await page.waitForTimeout(150);
    await page.locator('#edit-master-name').fill('鶏胸肉のサラダ(大盛り)');
    await page.locator('#edit-calories').fill('450');
    await page.locator('[data-edit-action="save"]').click();
    await page.waitForTimeout(150);
    const item = await page.evaluate(() => mealMaster.find(m => m.name === '鶏胸肉のサラダ(大盛り)'));
    expect(item).toBeTruthy();
    expect(item.calories).toBe(450);
  });
});

test.describe('training-log v44.8 — ⑥履歴のアコーディオン化', () => {
  test('運動の履歴(リスト)は、既定では個別の内容が閉じており、タップで開く', async ({ page }) => {
    await boot(page);
    await page.evaluate((y) => {
      entries.push({ id: 'e1', date: y, type: 'strength', part: '胸', exercise: 'ベンチプレス', reps: 10, weight: 50, createdAt: Date.now() });
      saveState();
    }, yesterday());
    await page.reload();
    await page.waitForTimeout(200);
    await page.locator('[data-tab="training"]').click();
    await page.waitForTimeout(150);
    const y = yesterday();
    const itemsBox = page.locator(`#history-items-${y}`);
    await expect(itemsBox).toHaveClass(/hidden/);
    await page.locator(`[data-action="toggle-history-day"][data-date="${y}"]`).click();
    await page.waitForTimeout(150);
    await expect(itemsBox).not.toHaveClass(/hidden/);
    await expect(itemsBox).toContainText('ベンチプレス');
  });

  test('食事の履歴も、既定では個別の内容が閉じており、合計(kcal)は常に見える', async ({ page }) => {
    await boot(page);
    await page.evaluate((y) => {
      mealEntries.push({ id: 'm1', date: y, mealType: '朝食', text: '納豆', calories: 100, createdAt: Date.now() });
      saveState();
    }, yesterday());
    await page.reload();
    await page.waitForTimeout(200);
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    const y = yesterday();
    const html = await page.locator('#tab-content').innerHTML();
    expect(html).toContain('計100kcal');
    const itemsBox = page.locator(`#meal-history-items-${y}`);
    await expect(itemsBox).toHaveClass(/hidden/);
    await page.locator(`[data-action="toggle-meal-history-day"][data-date="${y}"]`).click();
    await page.waitForTimeout(150);
    await expect(itemsBox).not.toHaveClass(/hidden/);
    await expect(itemsBox).toContainText('納豆');
  });
});

test.describe('training-log v44.8 — ⑦接続設定はマスク表示', () => {
  test('保存すると伏せ表示になり、「変更する」で編集・「キャンセル」で戻せる', async ({ page }) => {
    await page.route('https://script.google.com/macros/**', (route) => {
      route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ status: 'ok', payload: {}, lastWriteAt: null, written: 0 }) });
    });
    await boot(page);
    await page.locator('[data-tab="settings"]').click();
    await page.waitForTimeout(150);
    // 未設定の間は入力欄が見えている
    expect(await page.locator('#gas-url-input').count()).toBe(1);
    await page.locator('#gas-url-input').fill('https://script.google.com/macros/s/abcdef/exec');
    await page.locator('#gas-token-input').fill('mytoken');
    await page.locator('[data-action="save-gas-config"]').click();
    await page.waitForTimeout(300);

    expect(await page.locator('#gas-url-input').count()).toBe(0);
    expect(await page.locator('#tab-content').innerHTML()).toContain('登録済み');

    await page.locator('[data-action="reveal-gas-config"]').click();
    await page.waitForTimeout(150);
    expect(await page.locator('#gas-url-input').inputValue()).toBe('https://script.google.com/macros/s/abcdef/exec');
    expect(await page.locator('#gas-token-input').inputValue()).toBe('mytoken');

    await page.locator('[data-action="cancel-gas-edit"]').click();
    await page.waitForTimeout(150);
    expect(await page.locator('#gas-url-input').count()).toBe(0);
  });
});
