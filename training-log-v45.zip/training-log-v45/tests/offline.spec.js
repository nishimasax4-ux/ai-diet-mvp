// 開発者向け: v44で追加したサービスワーカー(オフライン起動)の回帰テストです。
// アプリの利用には不要なファイルです(無視して構いません)。
//   npx playwright test tests/offline.spec.js
//
// サービスワーカーは file:// では動かないため、このテストだけは
// 一時的なHTTPサーバーを立てて、実際にHTTP経由で検証します。
// GitHub Pagesと同じく Cache-Control: max-age=600 を付けて配信し、
// 「更新したのに古い画面が出続ける」状態にならないことも確認します。
const { test, expect } = require('@playwright/test');
const http = require('http');
const fs = require('fs');
const path = require('path');

const SRC = path.resolve(__dirname, '..');
// 版数はファイルから読む。バージョンを上げるたびにテストを直さなくて済むように。
const APP_VER = (fs.readFileSync(path.join(SRC, 'index.html'), 'utf8').match(/APP_VERSION = "([^"]+)"/) || [])[1];
const CACHE_NAME = 'training-log-' + APP_VER;
let server, port, html, sw;

// 配信するファイルはメモリ上に持ち、テストの中で書き換えられるようにする。
function reset() {
  html = fs.readFileSync(path.join(SRC, 'index.html'), 'utf8');
  sw = fs.readFileSync(path.join(SRC, 'sw.js'), 'utf8');
}
function setTitle(t) { html = html.replace(/<title>[^<]*<\/title>/, '<title>' + t + '</title>'); }

test.beforeAll(async () => {
  reset();
  server = http.createServer((req, res) => {
    const url = req.url.split('?')[0];
    const send = (body, type) => {
      res.writeHead(200, {
        'Content-Type': type,
        // GitHub Pagesと同じ条件。検証用のヘッダは出さず、期限だけで判断させる。
        'Cache-Control': 'max-age=600',
      });
      res.end(body);
    };
    if (url === '/traningAI/' || url === '/traningAI/index.html') return send(html, 'text/html; charset=utf-8');
    if (url === '/traningAI/sw.js') return send(sw, 'text/javascript; charset=utf-8');
    res.writeHead(404); res.end('nf');
  });
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  port = server.address().port;
});
test.afterAll(() => server && server.close());

const base = () => `http://127.0.0.1:${port}/traningAI/`;

async function bootWithSw(page) {
  await page.goto(base());
  await page.waitForFunction(() => navigator.serviceWorker && navigator.serviceWorker.controller !== null, null, { timeout: 15000 });
}

test.describe('training-log v44 — オフライン起動', () => {
  test.beforeEach(() => { reset(); });

  test('一度開いておけば、電波が無くてもアプリが起動する', async ({ page, context }) => {
    await bootWithSw(page);
    await page.evaluate(() => localStorage.setItem('offline-check', 'kept'));

    await context.setOffline(true);
    const res = await page.goto(base(), { waitUntil: 'load' });
    expect(res.status()).toBe(200);
    // 画面が実際に組み上がっていること(白い画面で終わっていない)。
    // 初回は案内(オンボーディング)、2回目以降はタブ画面が出る。
    expect(await page.evaluate(() => document.body.innerText.trim().length)).toBeGreaterThan(50);
    expect(await page.evaluate(() => typeof APP_VERSION !== 'undefined' && APP_VERSION)).toBe(APP_VER);
    // 記録も残っている
    expect(await page.evaluate(() => localStorage.getItem('offline-check'))).toBe('kept');
    await context.setOffline(false);
  });

  test('アプリを更新したら、次に開いたときすぐ新しい画面になる', async ({ page, context }) => {
    setTitle('V1');
    await bootWithSw(page);
    expect(await page.title()).toBe('V1');

    setTitle('V2');
    await page.goto(base(), { waitUntil: 'load' });
    // Cache-Control: max-age=600 が付いていても、古い画面が残らないこと。
    expect(await page.title()).toBe('V2');

    // 電波が無い状態でも、控えは新しいほうに入れ替わっている。
    await context.setOffline(true);
    await page.goto(base(), { waitUntil: 'load' });
    expect(await page.title()).toBe('V2');
    await context.setOffline(false);
  });

  test('Google Sheetsへの送信(POST)は横取りせず、控えにも残さない', async ({ page, context }) => {
    await bootWithSw(page);
    await context.setOffline(true);
    const out = await page.evaluate(async () => {
      try { const r = await fetch('/traningAI/', { method: 'POST', body: '{}' }); return 'status:' + r.status; }
      catch (e) { return 'failed'; }
    });
    // オフラインなら素直に失敗する(=控えを返して「送れたつもり」にならない)
    expect(out).toBe('failed');
    await context.setOffline(false);
  });

  test('バージョンが変わると、古い控えは削除される', async ({ page }) => {
    await bootWithSw(page);
    const keys = await page.evaluate(() => caches.keys());
    expect(keys).toEqual([CACHE_NAME]);

    // 前のバージョンの控えが残っている状態を作り、登録し直す
    await page.evaluate(() => caches.open('training-log-old').then(c => c.put('/traningAI/old', new Response('x'))));
    expect((await page.evaluate(() => caches.keys())).sort()).toEqual(['training-log-old', CACHE_NAME].sort());
    await page.evaluate(async () => { const r = await navigator.serviceWorker.getRegistration(); await r.unregister(); });
    await bootWithSw(page);
    await page.waitForFunction(async () => (await caches.keys()).length === 1, null, { timeout: 10000 });
    expect(await page.evaluate(() => caches.keys())).toEqual([CACHE_NAME]);
  });

  test('sw.jsの版数はアプリの版数と揃っている', () => {
    const app = (fs.readFileSync(path.join(SRC, 'index.html'), 'utf8').match(/APP_VERSION = "([^"]+)"/) || [])[1];
    const swv = (fs.readFileSync(path.join(SRC, 'sw.js'), 'utf8').match(/const VERSION = '([^']+)'/) || [])[1];
    expect(swv).toBe(app);
  });
});
