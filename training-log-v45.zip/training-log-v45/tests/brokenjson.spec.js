// 開発者向け: v44.1で入れた「崩れたAI応答の読み取り」の回帰テストです。
// アプリの利用には不要なファイルです(無視して構いません)。
//   npx playwright test tests/brokenjson.spec.js
//
// 実際に起きた不具合:「食事を写真」で『AIの応答を解釈できませんでした』。
// AIは答えを返していたのに、囲み・前置き・途中で切れた、のいずれかで
// 丸ごと捨てていたのが原因でした。
const { test, expect } = require('@playwright/test');
const path = require('path');
const APP = () => 'file://' + path.resolve(__dirname, '../index.html');

async function boot(page) {
  await page.goto(APP());
  for (let i = 0; i < 8; i++) {
    const f = page.locator('[data-ob-action="finish"]');
    if (await f.count()) { await f.click(); break; }
    const n = page.locator('[data-ob-action="next"]');
    if (await n.count()) { await n.click(); await page.waitForTimeout(30); } else break;
  }
  await page.waitForTimeout(120);
}
async function connect(page) {
  await page.evaluate(() => {
    gasConfig = { url: 'https://script.google.com/macros/s/fake/exec', token: 't', lastKnownWriteAt: null };
    saveConfig(); renderApp();
  });
}
function visionMock(page, text) {
  const seen = [];
  page.route('https://script.google.com/macros/**', (route, request) => {
    const body = JSON.parse(request.postData() || '{}');
    let out;
    if (body.action === 'aiVision') { seen.push(body); out = { status: 'ok', text }; }
    else if (body.action === 'ping') out = { status: 'ok', backendVersion: 'v999', ai: { gemini: true, groq: true } };
    else out = { status: 'ok', payload: {}, lastWriteAt: null, written: 0 };
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(out) });
  });
  return seen;
}
async function pickPhoto(page) {
  const buf = await page.evaluate(async () => {
    const c = document.createElement('canvas');
    c.width = 800; c.height = 600;
    const g = c.getContext('2d'); g.fillStyle = '#c33'; g.fillRect(0, 0, 800, 600);
    const b = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.9));
    return Array.from(new Uint8Array(await b.arrayBuffer()));
  });
  await page.setInputFiles('#photo-input', { name: 'meal.jpg', mimeType: 'image/jpeg', buffer: Buffer.from(buf) });
  await page.waitForTimeout(900);
}

const FOODS = '{"foods":[{"name":"鶏の唐揚げ(5個)","kcal":480,"protein":28,"fat":30,"carb":20}]}';

test.describe('training-log v44.1 — 崩れたAI応答の読み取り', () => {
  test('囲み・前置き・後書き・切れた応答のどれでも読み取れる', async ({ page }) => {
    await boot(page);
    const cases = [
      ['そのままのJSON', FOODS],
      ['```で囲まれている', '```json\n' + FOODS + '\n```'],
      ['閉じの```が無い', '```json\n' + FOODS],
      ['前置きの文章がある', 'はい、判定しました。\n' + FOODS],
      ['後ろに感想が付く', FOODS + '\n\nいかがでしょうか?'],
      ['前後どちらにも文章', '判定結果です:\n' + FOODS + '\nご確認ください。'],
      ['余分な改行と空白', '\n\n   ' + FOODS + '   \n'],
    ];
    for (const [label, text] of cases) {
      const got = await page.evaluate(t => {
        const p = parseAiJson_(t);
        const foods = photoFoodsFrom_(p);
        return foods && foods.length === 1 ? foods[0].name + '/' + foods[0].kcal : 'NG';
      }, text);
      expect(got, label).toBe('鶏の唐揚げ(5個)/480');
    }
  });

  test('途中で切れた応答からは、完成している料理だけを拾う', async ({ page }) => {
    await boot(page);
    const truncated =
      '{"foods":[{"name":"ご飯(茶碗1杯)","kcal":252,"protein":3.8,"fat":0.5,"carb":55.7},' +
      '{"name":"焼き鮭","kcal":180,"protein":22,"fat":9,"carb":0.1},' +
      '{"name":"ほうれん草のお';   // ← ここで上限に達して切れた
    const got = await page.evaluate(t => {
      const foods = photoFoodsFrom_(parseAiJson_(t));
      return foods ? foods.map(f => f.name) : null;
    }, truncated);
    expect(got).toEqual(['ご飯(茶碗1杯)', '焼き鮭']);
  });

  test('配列だけの応答や、日本語のキー名でも読み取れる', async ({ page }) => {
    await boot(page);
    const arrayOnly = '[{"name":"カレーライス","kcal":700,"protein":18,"fat":22,"carb":100}]';
    expect(await page.evaluate(t => {
      const f = photoFoodsFrom_(parseAiJson_(t));
      return f && f[0].name + '/' + f[0].kcal;
    }, arrayOnly)).toBe('カレーライス/700');

    const jpKeys = '{"foods":[{"料理名":"味噌汁","カロリー":40,"たんぱく質":3,"脂質":1.5,"炭水化物":4}]}';
    expect(await page.evaluate(t => {
      const f = photoFoodsFrom_(parseAiJson_(t));
      return f && [f[0].name, f[0].kcal, f[0].protein, f[0].fat, f[0].carb].join('/');
    }, jpKeys)).toBe('味噌汁/40/3/1.5/4');
  });

  test('本当に読み取れないときは、AIの返事をそのまま画面に出す', async ({ page }) => {
    await boot(page);
    visionMock(page, 'すみません、この写真からは判断できません。');
    await connect(page);
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    await pickPhoto(page);

    const html = await page.locator('#tab-content').innerText();
    expect(html).toContain('読み取れませんでした');
    // 何が返ってきたのかが分かること(ここが無いと原因を絞り込めない)
    expect(html).toContain('この写真からは判断できません');
  });

  test('「料理が写っていない」は、エラーではなく案内として出す', async ({ page }) => {
    await boot(page);
    visionMock(page, '{"foods":[]}');
    await connect(page);
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    await pickPhoto(page);
    const text = await page.locator('#tab-content').innerText();
    expect(text).toContain('判別できませんでした');
    expect(text).not.toContain('読み取れませんでした');
  });

  test('囲まれた応答から、実際に候補が並ぶところまで通る', async ({ page }) => {
    await boot(page);
    visionMock(page, '```json\n' + FOODS + '\n```');
    await connect(page);
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    await pickPhoto(page);
    expect(await page.locator('#tab-content').innerHTML()).toContain('鶏の唐揚げ(5個)');
  });

  test('写真判定は上限を広げ、JSONモードを要求して送る', async ({ page }) => {
    await boot(page);
    const seen = visionMock(page, FOODS);
    await connect(page);
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    await pickPhoto(page);
    expect(seen.length).toBe(1);
    expect(seen[0].json).toBe(true);
    expect(seen[0].maxTokens).toBe(1500);
  });

  test('壊れた入力で例外を投げない(nullを返して呼び出し側に判断させる)', async ({ page }) => {
    await boot(page);
    const bad = ['', '   ', 'ただの文章です', '{"foods":', '}{', '[[[', null, undefined,
                 '{"foods":"文字列"}', '{"other":123}'];
    const got = await page.evaluate(list => list.map(t => {
      try { return photoFoodsFrom_(parseAiJson_(t)) === null ? 'null' : 'value'; }
      catch (e) { return 'THREW:' + e.message; }
    }), bad);
    expect(got.every(g => g === 'null')).toBe(true);
  });
});
