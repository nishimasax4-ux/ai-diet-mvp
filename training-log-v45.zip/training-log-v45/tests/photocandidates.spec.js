// 開発者向け: v44.2「写真から3つの候補を出して選ぶ」の回帰テストです。
// アプリの利用には不要なファイルです(無視して構いません)。
//   npx playwright test tests/photocandidates.spec.js
//
// 背景: AIが料理を取り違えたとき、写真を撮り直すしかなかった。
// 違う料理の候補を3件出して、その場で選べるようにした。
const { test, expect } = require('@playwright/test');
const path = require('path');
const APP = () => 'file://' + path.resolve(__dirname, '../index.html');

async function boot(page) {
  await page.goto(APP());
  for (let i = 0; i < 8; i++) {
    const f = page.locator('[data-ob-action="finish"]');
    if (await f.count()) { await f.click(); break; }
    const n = page.locator('[data-ob-action="next"]');
    if (await n.count()) { await n.click(); await page.waitForTimeout(30); } else break;
  }
  await page.waitForTimeout(120);
}
function mock(page, text) {
  const seen = [];
  page.route('https://script.google.com/macros/**', (route, request) => {
    const body = JSON.parse(request.postData() || '{}');
    let out;
    if (body.action === 'aiVision') { seen.push(body); out = { status: 'ok', text }; }
    else if (body.action === 'ping') out = { status: 'ok', backendVersion: 'v999', ai: { gemini: true, groq: true } };
    else out = { status: 'ok', payload: {}, lastWriteAt: null, written: 0 };
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(out) });
  });
  return seen;
}
async function connect(page) {
  await page.evaluate(() => {
    gasConfig = { url: 'https://script.google.com/macros/s/fake/exec', token: 't', lastKnownWriteAt: null };
    saveConfig(); renderApp();
  });
  await page.locator('[data-tab="meals"]').click();
  await page.waitForTimeout(150);
}
async function pickPhoto(page) {
  const buf = await page.evaluate(async () => {
    const c = document.createElement('canvas');
    c.width = 800; c.height = 600;
    const g = c.getContext('2d'); g.fillStyle = '#c33'; g.fillRect(0, 0, 800, 600);
    const b = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.9));
    return Array.from(new Uint8Array(await b.arrayBuffer()));
  });
  await page.setInputFiles('#photo-input', { name: 'meal.jpg', mimeType: 'image/jpeg', buffer: Buffer.from(buf) });
  await page.waitForTimeout(900);
}

// 1品の写真 → 違う料理の候補が3件
const ALTERNATIVES = JSON.stringify({
  mode: 'alternatives',
  foods: [
    { name: '鶏の唐揚げ(5個)', kcal: 480, protein: 28, fat: 30, carb: 20, note: '衣が薄めならこちら' },
    { name: 'ヤンニョムチキン(5個)', kcal: 560, protein: 26, fat: 30, carb: 40, note: '赤いタレが絡んでいる場合' },
    { name: '竜田揚げ(5個)', kcal: 450, protein: 29, fat: 26, carb: 18, note: '衣が白っぽく粉っぽい場合' },
  ],
});
// 定食の写真 → 写っているものを1件ずつ
const ITEMS = JSON.stringify({
  mode: 'items',
  foods: [
    { name: 'ご飯(茶碗1杯)', kcal: 252, protein: 3.8, fat: 0.5, carb: 55.7, note: '茶碗の大きさから1杯と判断' },
    { name: '焼き鮭', kcal: 180, protein: 22, fat: 9, carb: 0.1, note: '切り身1切れ' },
    { name: '味噌汁', kcal: 40, protein: 3, fat: 1.5, carb: 4, note: 'わかめと豆腐' },
  ],
});

test.describe('training-log v44.2 — 写真から候補を選ぶ', () => {
  test('取り違えやすい料理の候補が3件並び、それぞれ選べる', async ({ page }) => {
    await boot(page);
    mock(page, ALTERNATIVES);
    await connect(page);
    await pickPhoto(page);

    const card = page.locator('.card').filter({ hasText: '写真から記録' });
    await expect(card.locator('[data-action="use-meal-suggestion"]')).toHaveCount(3);
    await expect(card).toContainText('鶏の唐揚げ(5個)');
    await expect(card).toContainText('ヤンニョムチキン(5個)');
    await expect(card).toContainText('竜田揚げ(5個)');
    // 「どれか1つを選ぶ」と分かる見出しになっていること
    await expect(card).toContainText('近いものをタップ');

    // 1件目ではなく2件目を選べる(取り違えていても撮り直さずに済む)
    await card.locator('[data-action="use-meal-suggestion"]').nth(1).click();
    await page.waitForTimeout(300);
    expect(await page.locator('#meal-name-input').inputValue()).toBe('ヤンニョムチキン(5個)');
    expect(await page.locator('#meal-cal-input').inputValue()).toBe('560');
  });

  test('候補ごとに「なぜその候補か」が出る', async ({ page }) => {
    await boot(page);
    mock(page, ALTERNATIVES);
    await connect(page);
    await pickPhoto(page);
    const card = page.locator('.card').filter({ hasText: '写真から記録' });
    await expect(card).toContainText('衣が薄めならこちら');
    await expect(card).toContainText('赤いタレが絡んでいる場合');
  });

  test('定食は「1つずつ記録できる」と案内し、続けて記録できる', async ({ page }) => {
    await boot(page);
    mock(page, ITEMS);
    await connect(page);
    await pickPhoto(page);

    const card = page.locator('.card').filter({ hasText: '写真から記録' });
    await expect(card).toContainText('1つずつタップして記録');

    // 1件目を記録
    await card.locator('[data-action="use-meal-suggestion"]').first().click();
    await page.waitForTimeout(250);
    await page.locator('[data-action="add-meal"]').click();
    await page.waitForTimeout(400);
    expect(await page.evaluate(() => mealEntries.length)).toBe(1);

    // 記録したあとも候補が残っていて、2件目もそのまま記録できること
    const card2 = page.locator('.card').filter({ hasText: '写真から記録' });
    await expect(card2.locator('[data-action="use-meal-suggestion"]')).toHaveCount(3);
    await card2.locator('[data-action="use-meal-suggestion"]').nth(1).click();
    await page.waitForTimeout(250);
    // 内蔵辞書に同じものがあれば辞書の名前・値が入る(v43からの仕様)。
    // ここで見たいのは「2件目が選べること」なので、候補の名前と一致していればよい。
    const second = await page.evaluate(() => photoResults[1].name);
    expect(await page.locator('#meal-name-input').inputValue()).toBe(second);
    await page.locator('[data-action="add-meal"]').click();
    await page.waitForTimeout(400);
    expect(await page.evaluate(() => mealEntries.length)).toBe(2);
  });

  test('どれも違うときの逃げ道を必ず案内する(撮り直しを勧めない)', async ({ page }) => {
    await boot(page);
    mock(page, ALTERNATIVES);
    await connect(page);
    await pickPhoto(page);
    const card = page.locator('.card').filter({ hasText: '写真から記録' });
    await expect(card).toContainText('写真を撮り直さなくても大丈夫');
    await expect(card).toContainText('AIで栄養を調べる');
  });

  test('AIへの指示に「候補を3件」と「違う料理を挙げる」が入っている', async ({ page }) => {
    await boot(page);
    const seen = mock(page, ALTERNATIVES);
    await connect(page);
    await pickPhoto(page);
    expect(seen.length).toBe(1);
    expect(seen[0].prompt).toContain('候補を3件');
    expect(seen[0].prompt).toContain('違う料理');
    expect(seen[0].prompt).toContain('alternatives');
    expect(seen[0].prompt).toContain('items');
  });

  test('modeが無い古い応答でも、候補はこれまでどおり表示される', async ({ page }) => {
    await boot(page);
    mock(page, '{"foods":[{"name":"カレーライス","kcal":700,"protein":18,"fat":22,"carb":100}]}');
    await connect(page);
    await pickPhoto(page);
    const card = page.locator('.card').filter({ hasText: '写真から記録' });
    await expect(card).toContainText('カレーライス');
    await expect(card).toContainText('判定した候補');
    await expect(card).not.toContainText('1つずつタップして記録');
  });

  test('登録済みの値を優先しても、候補の説明は消えない', async ({ page }) => {
    await boot(page);
    mock(page, ALTERNATIVES);
    await connect(page);
    await page.evaluate(() => {
      mealMaster.push({ id: uid(), name: '鶏の唐揚げ(5個)', calories: 400, protein: 30, fat: 22, carb: 18 });
      saveState();
    });
    await pickPhoto(page);
    const res = await page.evaluate(() => photoResults);
    expect(res[0].source).toBe('master');
    expect(res[0].kcal).toBe(400);              // 自分の登録値が勝つ
    expect(res[0].note).toBe('衣が薄めならこちら'); // 説明は残る
  });

  test('新しい写真を撮ると、前の候補は残らない', async ({ page }) => {
    await boot(page);
    mock(page, ALTERNATIVES);
    await connect(page);
    await pickPhoto(page);
    expect(await page.evaluate(() => photoResults.length)).toBe(3);
    await page.evaluate(() => { photoStatus = 'idle'; photoResults = null; photoMode = null; renderTabContent(); });
    expect(await page.evaluate(() => photoMode)).toBe(null);
  });
});
