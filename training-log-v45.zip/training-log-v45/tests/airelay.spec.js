// 開発者向け: v44で入れた「AIへの指示文はアプリ側、Apps Scriptは中継するだけ」の
// 仕組みの回帰テストです。アプリの利用には不要なファイルです。
//   npx playwright test tests/airelay.spec.js
const { test, expect } = require('@playwright/test');
const path = require('path');
const APP = () => 'file://' + path.resolve(__dirname, '../index.html');

async function boot(page) {
  await page.goto(APP());
  for (let i = 0; i < 8; i++) {
    const f = page.locator('[data-ob-action="finish"]');
    if (await f.count()) { await f.click(); break; }
    const n = page.locator('[data-ob-action="next"]');
    if (await n.count()) { await n.click(); await page.waitForTimeout(30); } else break;
  }
  await page.waitForTimeout(120);
}
async function connect(page) {
  await page.evaluate(() => {
    gasConfig = { url: 'https://script.google.com/macros/s/fake/exec', token: 'SECRET-TOKEN', lastKnownWriteAt: null };
    saveConfig(); renderApp();
  });
}
// AI中継の呼び出しだけ記録し、それ以外(save/load/ping)は当たり障りのない応答を返す。
function relayMock(page, reply) {
  const seen = [];
  page.route('https://script.google.com/macros/**', (route, request) => {
    const body = JSON.parse(request.postData() || '{}');
    let out;
    if (body.action === 'aiText' || body.action === 'aiVision') {
      seen.push(body);
      out = reply(body);
    } else if (body.action === 'ping') {
      out = { status: 'ok', backendVersion: 'v999', ai: { gemini: true, groq: true } };
    } else {
      out = { status: 'ok', payload: {}, lastWriteAt: null, written: 0 };
    }
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(out) });
  });
  return seen;
}

test.describe('training-log v44 — AI中継', () => {
  test('栄養検索の指示文はアプリ側で組み立てて送られる', async ({ page }) => {
    await boot(page);
    const seen = relayMock(page, () => ({ status: 'ok', text: '{"kcal":250,"protein":20.5,"fat":8.1,"carb":22.3}' }));
    await connect(page);
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    await page.locator('#meal-name-input').fill('鶏むね肉のグリル(自作)');
    await page.locator('[data-action="ai-lookup-nutrition"][data-target="meal"]').click();
    await page.waitForTimeout(700);

    expect(seen.length).toBe(1);
    expect(seen[0].action).toBe('aiText');
    expect(seen[0].preset).toBe('nutrition');
    // 指示文の本体がアプリから送られていること
    expect(seen[0].prompt).toContain('鶏むね肉のグリル(自作)');
    expect(seen[0].prompt).toContain('"kcal"');
    // 応答は入力欄に反映される
    expect(await page.locator('#meal-cal-input').inputValue()).toBe('250');
    expect(await page.locator('#meal-protein-input').inputValue()).toBe('20.5');
  });

  test('AIの応答が```で囲まれていても読み取れる', async ({ page }) => {
    await boot(page);
    relayMock(page, () => ({ status: 'ok', text: '```json\n{"kcal":300,"protein":10,"fat":9,"carb":40}\n```' }));
    await connect(page);
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    await page.locator('#meal-name-input').fill('謎のごはん(未登録)');
    await page.locator('[data-action="ai-lookup-nutrition"][data-target="meal"]').click();
    await page.waitForTimeout(700);
    expect(await page.locator('#meal-cal-input').inputValue()).toBe('300');
  });

  test('JSONとして読めない応答は、黙って0kcalにせずエラーとして知らせる', async ({ page }) => {
    await boot(page);
    relayMock(page, () => ({ status: 'ok', text: 'すみません、わかりません。' }));
    await connect(page);
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    await page.locator('#meal-name-input').fill('判定できないもの(未登録)');
    await page.locator('[data-action="ai-lookup-nutrition"][data-target="meal"]').click();
    await page.waitForTimeout(700);
    const status = await page.locator('#ai-lookup-meal-status').textContent();
    expect(status).toContain('読み取れませんでした');
    expect(await page.locator('#meal-cal-input').inputValue()).toBe('');
  });

  test('アプリはモデル名を指定せず、APIキーも送らない', async ({ page }) => {
    await boot(page);
    const seen = relayMock(page, () => ({ status: 'ok', text: 'よく続いています。' }));
    await connect(page);
    await page.locator('[data-tab="today"]').click();
    await page.waitForTimeout(150);
    await page.locator('[data-action="fetch-ai-advice"]').click();
    await page.waitForTimeout(700);

    expect(seen.length).toBe(1);
    expect(seen[0].preset).toBe('advice');
    const json = JSON.stringify(seen[0]);
    // 使うモデルを決めるのはApps Script側。アプリからは用途名しか送らない。
    expect(json).not.toContain('gemini-');
    expect(json).not.toContain('llama');
    expect(json).not.toContain('model');
    // APIキーはアプリ側に存在しない(合言葉のtokenだけが付く)
    expect(json).not.toMatch(/gsk_|AIza/);
    expect(seen[0].token).toBe('SECRET-TOKEN');
  });

  test('写真判定もaiVisionで中継され、指示文と画像がアプリから送られる', async ({ page }) => {
    await boot(page);
    const seen = relayMock(page, () => ({
      status: 'ok',
      text: '{"foods":[{"name":"鶏の唐揚げ(5個)","kcal":480,"protein":28,"fat":30,"carb":20}]}',
    }));
    await connect(page);
    await page.locator('[data-tab="meals"]').click();
    await page.waitForTimeout(150);
    const buf = await page.evaluate(async () => {
      const c = document.createElement('canvas');
      c.width = 800; c.height = 600;
      const g = c.getContext('2d'); g.fillStyle = '#c33'; g.fillRect(0, 0, 800, 600);
      const b = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.9));
      return Array.from(new Uint8Array(await b.arrayBuffer()));
    });
    await page.setInputFiles('#photo-input', { name: 'meal.jpg', mimeType: 'image/jpeg', buffer: Buffer.from(buf) });
    await page.waitForTimeout(900);

    expect(seen.length).toBe(1);
    expect(seen[0].action).toBe('aiVision');
    expect(seen[0].prompt).toContain('写真に写っている食事');
    expect(seen[0].mimeType).toBe('image/jpeg');
    expect(seen[0].imageBase64.length).toBeGreaterThan(100);
    expect(await page.locator('#tab-content').innerHTML()).toContain('鶏の唐揚げ(5個)');
  });

  test('応答を待っている間に連打しても、二重に問い合わせない(無料枠の節約)', async ({ page }) => {
    await boot(page);
    // 応答が返るまで少し間を置き、実際の通信のように「待っている状態」を作る。
    const seen = [];
    await page.route('https://script.google.com/macros/**', async (route, request) => {
      const body = JSON.parse(request.postData() || '{}');
      let out;
      if (body.action === 'aiText') {
        seen.push(body);
        await new Promise(r => setTimeout(r, 900));
        out = { status: 'ok', text: 'よく続いています。' };
      } else if (body.action === 'ping') {
        out = { status: 'ok', backendVersion: 'v999', ai: { gemini: true, groq: true } };
      } else {
        out = { status: 'ok', payload: {}, lastWriteAt: null, written: 0 };
      }
      route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(out) });
    });
    await connect(page);
    await page.locator('[data-tab="today"]').click();
    await page.waitForTimeout(150);
    await page.locator('[data-action="fetch-ai-advice"]').click();
    await page.waitForTimeout(150);
    await page.locator('[data-action="fetch-ai-advice"]').click().catch(() => {});   // 応答待ちのうちに連打
    await page.waitForTimeout(1400);
    expect(seen.length).toBe(1);
    expect(await page.locator('#tab-content').innerHTML()).toContain('よく続いています。');
  });
});
